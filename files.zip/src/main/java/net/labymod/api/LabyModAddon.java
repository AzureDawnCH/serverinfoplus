package net.labymod.api;

/**
 * Minimaler Compile‑Stub der LabyMod Addon-Basis.
 * Der echte LabyMod‑Client stellt zur Laufzeit die richtige Klasse bereit.
 */
public abstract class LabyModAddon {
    /**
     * Wird ausgeführt, wenn das Addon geladen wird.
     */
    public void onEnable() {}

    /**
     * Vereinfachte Logger-Methode (Stub).
     */
    public void info(String msg) {
        System.out.println("[LabyMod-Stub] " + msg);
    }
}