package de.azuredawnch.serverinfoplus.ui;

import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;

/**
 * Einfacher, plattformunabhängiger Pseudo-HUD-Stummkopf.
 * In der echten LabyMod-API würdest du hier Renderer/HUD-Registrierung nutzen.
 * Diese Klasse simuliert die Erfassung von Ping-Daten und einen kleinen "Graph"-Puffer.
 */
public class PingHud {

    private final Deque<Integer> pingHistory = new ArrayDeque<>();
    private final int maxSamples = 40;
    private final Random random = new Random();

    public void start() {
        // Start-Mock: In echter Implementierung: Scheduler/Listener für Netzwerk-Pings
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ignored) {}
                int ping = samplePing();
                pushPing(ping);
                // Ausgabe zur Demonstration (konsole)
                System.out.println("[ServerInfoPlus] " + Instant.now() + " Ping: " + ping + "ms | Avg: " + avgPing());
            }
        }, "ServerInfoPlus-PingThread").start();
    }

    private int samplePing() {
        // Mock: echte Messung läuft über native API/Packet-Timestamps
        return 30 + random.nextInt(120);
    }

    private void pushPing(int ping) {
        if (pingHistory.size() >= maxSamples) {
            pingHistory.removeFirst();
        }
        pingHistory.addLast(ping);
    }

    private int avgPing() {
        return pingHistory.stream().mapToInt(Integer::intValue).sum() / Math.max(1, pingHistory.size());
    }
}