package de.azuredawnch.serverinfoplus;

import net.labymod.api.LabyModAddon;

/**
 * Hauptklasse des Addons.
 * Diese Klasse ist bewusst klein gehalten — die eigentliche HUD/Logik ist in PingHud ausgelagert.
 */
public class ServerInfoPlusAddon extends LabyModAddon {

    private PingHud pingHud;

    @Override
    public void onEnable() {
        info("ServerInfoPlus wird aktiviert...");
        // HUD initialisieren
        this.pingHud = new PingHud();
        this.pingHud.start();
        info("ServerInfoPlus aktiviert. HUD läuft.");
    }
}